// Reapply an exact committed reconstruction, then invoke its actual scene/fidelity keeper.
// The only writes outside the report folder are private, isolated temporary variant inputs.
import assert from 'node:assert/strict';
import { cp, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { CORPUS } from '../../../test/fixtures/motion-corpus/corpus.ts';
import { applyEdits, POPPY_FOLDERS } from '../../../tools/repo/motion-corpus-lib.ts';
import { loadFonts, loadProject } from '../../../explain/testing.ts';

const specs = {
  'poppy-key-over-station-name': { scenario: { approve: 'read-write' }, message: /authored agent:key:(flight|return) hides \d+ painted text pixels/ },
  'refusals-key-over-lane-name': { test: 'the replacement keys clear', message: /API key hides \d+ painted text pixels/ },
  'browser-read-across-page': { scenario: {signin: 'signed-in'}, message: /authored read hides \d+ painted text pixels/ },
  'browser-forge-ends-on-stop': { scenario: {signin: 'signed-in'}, message: /forged-stub landing hides \d+ painted drawing pixels/ },
  'discovery-path-slides': { test: 'redirect replaces the joined address', message: /the readable path detached from its host|host and path must be replaced together/ },
};

const id = process.argv[2], variant = process.argv[3] !== 'baseline';
const spec = specs[id], entry = CORPUS.find(e => e.id === id);
assert.ok(spec && entry);
const repo = resolve(import.meta.dirname, '../../..');
const root = await mkdtemp(join(tmpdir(), 'astra-owner-replay-'));
try {
  for (const dir of ['node_modules', 'src', 'tools', 'explain', 'test', 'extras', 'app', 'integrations', 'vendor', 'package.json'])
    await symlink(join(repo, dir), join(root, dir));
  const folder = join(root, 'scenes', 'explainers'), chapter = join(folder, entry.chapter);
  await mkdir(folder, {recursive: true});
  for (const name of POPPY_FOLDERS) {
    const from = join(repo, 'scenes', 'explainers', name), to = join(folder, name);
    if (name === entry.chapter) await cp(from, to, {recursive: true});
    else await symlink(from, to);
  }
  if (variant) {
    for (const name of new Set(entry.edits.map(edit => edit.file))) {
      assert.ok(name.startsWith(entry.chapter + '/'), 'only write the private copy');
      const file = join(folder, name);
      await writeFile(file, applyEdits(await readFile(file, 'utf8'), entry.edits.filter(e => e.file === name), id));
    }
  }
  let failure;
  if (spec.test) {
    try {
      await promisify(execFile)(process.execPath, ['--test', '--test-reporter=tap', '--test-name-pattern', spec.test, join(chapter, 'scene.test.ts')],
        {cwd: repo, maxBuffer: 2_000_000});
    } catch (e) {
      assert.equal(e.code, 1, 'actual test ran and produced an assertion failure');
      failure = e.stdout;
    }
  } else {
    await loadFonts();
    const { default: Source } = await import(pathToFileURL(join(chapter, 'scene.ts')));
    const { check } = await import(pathToFileURL(join(chapter, 'fidelity.ts')));
    const project = await loadProject(Source, chapter);
    const scenario = project.scenarios.find(s => Object.entries(spec.scenario).every(([k, v]) => s.values[k] === v));
    assert.ok(scenario);
    try { await check(scenario.trace, scenario.values, { project, scenario, walks: [] }); }
    catch (e) { assert.ok(e instanceof assert.AssertionError); failure = e.message; }
  }
  if (variant) {
    assert.ok(failure, id + ': reconstructed case passed the scene owner');
    assert.match(failure, spec.message, id + ': wrong failure: ' + failure.slice(0, 1500));
  } else assert.equal(failure, undefined);
  console.log(JSON.stringify({id, variant, outcome: variant ? 'expected owner rejection' : 'owner passed',
    reason: failure?.split('\n').map(s => s.trim()).find(s => spec.message.test(s)) ?? null}));
} finally { await rm(root, {recursive: true, force: true}); }
