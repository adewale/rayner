import assert from 'node:assert/strict';
import { readFile, mkdtemp, writeFile, rm } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { CORPUS } from '../../../test/fixtures/motion-corpus/corpus.ts';
import { againstBaseline, guardRefusal, findingId } from '../../../tools/repo/motion-corpus-lib.ts';
import { recall, runInChild } from '../../../tools/repo/motion-corpus.ts';

const input = 'docs/evidence/motion-sol61-2026-11-21/';
const raw = JSON.parse(gunzipSync(await readFile(input + 'corpus-findings.json.gz')));
const summary = JSON.parse(await readFile(input + 'corpus.json'));
const visual = JSON.parse(await readFile('docs/evidence/motion-all59-2026-11-21/audit.json'));
const provenance = JSON.parse(gunzipSync(await readFile(input + 'measurement-sources.json.gz')));
const serial = item => JSON.stringify(item, (_, v) => v instanceof RegExp ? {pattern:v.source, flags:v.flags} : v);
const changedMetadata = [];
for (const entry of CORPUS) {
  const {expectedFinding: now, ...other} = entry, {expectedFinding: then, ...captured} = provenance.entries.find(r => r.id === entry.id);
  assert.deepEqual(JSON.parse(serial(other)), captured);
  if (serial(now) !== serial(then)) changedMetadata.push(entry.id);
}
assert.deepEqual(changedMetadata, raw.measurementAmendment.attributionAddedAfterCapture);
const baseByChapter = new Map(raw.baselines.map(x => [x.id.slice(5), x]));
assert.equal(baseByChapter.size, 8);
for (const base of baseByChapter.values()) {assert.equal(base.error, undefined); assert.equal(base.findings.length, 0);}
const byId = new Map(raw.results.map(r => [r.id,r]));
assert.equal(byId.size, 59);
const remade = CORPUS.map(e => againstBaseline(byId.get(e.id), baseByChapter.get(e.chapter), e.expectedFinding));
const result = recall(CORPUS, remade);
assert.deepEqual(result, raw.summary);
assert.deepEqual(result, summary.summary);
const grade = {exact: 0, guard: 0, any: 0, missed: 0}, visualCross = {};
for (const [i, entry] of CORPUS.entries()) {
  const r = remade[i], c = summary.cases.find(c => c.id === entry.id);
  assert.equal(r.caught, c.rejected);
  const reason = c.guardOnly ? 'guard' : !r.caught ? 'missed' : entry.expectedFinding ? 'exact' : 'any';
  grade[reason]++;
  const frozen = visual.cases.find(c => c.id === entry.id).verdict;
  const row = visualCross[frozen] ??= {};
  row[reason] = (row[reason] ?? 0) + 1;
}
const old = JSON.parse(await readFile('docs/evidence/motion-root-causes-2026-11-21/corpus.json'));
const past = new Set(old.cases.filter(c => c.rejected).map(c => c.id));
assert.equal(past.size, 37); assert.ok([...past].every(id => byId.get(id).caught));
const sessions = CORPUS.find(e => e.id === 'sessions-too-long');
const unrelatedWarning = {scenario:'{}', line:'after unrelated-event: flicker: part “unrelated” at 0.200 s went away and came back'};
const otherError = new RangeError('machine.send("unrelated-event"): authored transition lasts 7.000 s but the event allows 1.000 s; unrelated fixture');
const otherGuard = guardRefusal(sessions, otherError);
assert.ok(otherGuard);
const row = (id, findings, caught = findings.length > 0) => ({id, findings, fresh: findings, caught, ms: 1});
const fakeScores = [unrelatedWarning, otherGuard].map(f => {
  const r = againstBaseline(row(sessions.id, [f]), baseByChapter.get(sessions.chapter), sessions.expectedFinding);
  return recall([sessions], [r]).caught;
});
assert.deepEqual(fakeScores, [1, 1]);
const emptyCredit = recall([sessions], [row(sessions.id, [], true)]).caught;
assert.equal(emptyCredit, 1);
const cover = target => ({scenario:'{}', line:'after send: covers: part “ticket” at 0.400 s travels over “'+target+'” (part “'+target+'”), covering 100% of it, for 0.20 s before it lands; fix: move it'});
assert.equal(findingId(cover('A')), findingId(cover('B')));
const baselineComparison = againstBaseline(row('some-case',[cover('B')]),row('base-chapter',[cover('A')]));
assert.equal(baselineComparison.caught, false);
const simulate = await mkdtemp(join(tmpdir(), 'astra-protocol-'));
const previousOptions = process.env.NODE_OPTIONS;
let protocol;
try {
  const preload = join(simulate,'exit-after-record.mjs');
  await writeFile(preload, "if (process.argv[2] === '--entry') { const f = " + JSON.stringify(unrelatedWarning) +
    "; process.stdout.write(JSON.stringify({id:process.argv[3],caught:true,findings:[f],fresh:[f],ms:0}), () => process.exit(17)); }");
  process.env.NODE_OPTIONS = (previousOptions ? previousOptions + ' ' : '') + '--import=' + preload;
  protocol = await runInChild('sessions-too-long');
  assert.equal(protocol.error, undefined);
  const graded = againstBaseline(protocol, baseByChapter.get(sessions.chapter), sessions.expectedFinding);
  assert.equal(recall([sessions], [graded]).caught, 1);
} finally {
  if (previousOptions === undefined) delete process.env.NODE_OPTIONS;
  else process.env.NODE_OPTIONS = previousOptions;
  await rm(simulate,{recursive:true, force:true});
}
console.log(JSON.stringify({score:result,partition:grade,frozenVisualByCredit:visualCross,addedAttribution:changedMetadata,
  recordedSessions:byId.get(sessions.id).fresh, fakeScores, emptyCaughtTrueScores:emptyCredit, coverVictimBMaskedByBaselineVictimA:!baselineComparison.caught,
  nonzeroExit17WithValidJsonAccepted:protocol.error === undefined}, null, 2));
