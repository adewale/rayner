import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {Group, Scene, Circle, Rectangle, Line, Succession, keyed, toSvgString} from '../../../src/index.ts';
import {Machine, view} from '../../../explain/index.ts';
import {pass} from '../../../explain/drawing.ts';
import {exploreMachines} from '../../../tools/lib/explain-check.ts';
import {MachineMotionCheck} from '../../../tools/lib/explain-motion-rules.ts';
import {rasterize} from '../../../tools/lib/explain-raster.ts';

const sceneRoot = new URL('./paint-and-cost.json', import.meta.url);

async function trial(kind) {
  const observations = [], checker = new MachineMotionCheck();
  let movement;
  class Delivery extends Scene {
    state = {sent: false};
    async construct() {
      const world = view(this, () => new Group(keyed(new Rectangle({width: .4, height: .4, fill: '#00ff00', stroke: 'none'}), 'legend')), {place: false});
      const x = kind === 'thin-stage-edge' ? -8.18 : 7.7;
      const machine = new Machine(this, {
        start: this.state, events: ['ship'], views: [world], runTime: 1.2,
        next: st => st.sent ? undefined : {sent: true},
        motion: () => [{view: world, during: 'parcel', present: ['legend']}],
        transition: {ship: t => {
          const ch = t.choreograph(world), token = new Rectangle({width: .4, height: .4, stroke: 'none', fill: '#ff0000'});
          const trip = pass(ch, 'parcel', token, [[x,-1.2], [x,1.2]], {appear:.1, move:.6, leave:.1});
          movement = trip[1];
          return new Succession([...trip, ch.rest({runTime:.1})]);
        }},
      });
      this.add(world);
      if (kind === 'covered') {
        const wall = new Group(new Line([8.7,-2], [8.7,2], {stroke:'#555555',strokeWidth:2.6}));
        this.add(wall);
      }
      await this.step('ship');
      await this.play(machine.send('ship'));
    }
  }
  const sample = async (scene, cull) => {
    const img = await rasterize(toSvgString(scene, {width:800, cull})), a=img.pixels;
    let reds=0, sumY=0, gray=0;
    for (let i=0; i<a.length; i+=4) {
      if (a[i]>200 && a[i+1]<100 && a[i+2]<100) {
        reds++; sumY+=Math.floor((i/4)/img.width);
      }
      if (a[i]===85 && a[i+1]===85 && a[i+2]===85) gray++;
    }
    return {reds, y: reds ? +(sumY/reds).toFixed(2) : null, gray};
  };
  const scene = new Delivery({async frame(s) {
    await checker.frame(s);
    if (movement?.phase !== 'begun') return;
    const [visible, culled] = await Promise.all([sample(s, false), sample(s, true)]);
    observations.push({frame:s.frameCount, visible, culled});
  }});
  await checker.during(scene, ()=>scene.run());
  return {findings: checker.findings, frames:observations};
}

async function cost(states, withResult) {
  let resultCalls=0, nextCalls=0;
  class Chain extends Scene {
    state = {n:0};
    async construct() {
      const machine = new Machine(this, {
        start:this.state, events:['step'], views:[], limit:states,
        next: st => {nextCalls++; return st.n+1<states ? {n:st.n+1} : undefined;},
        ...(withResult && {result: ({after}) => {resultCalls++; return {number:after.n};}}),
      });
      await this.step('offer');
      machine.offer();
    }
  }
  const source = await new Chain({async frame(){}}).run();
  // Independent inventory: n durable states, n-1 accepted edges. Set layouts explicitly
  // and skip downstream animation checking to isolate just context construction.
  const t=performance.now();
  const [walk] = await exploreMachines(source,Chain,new Map(),{events:[]});
  return {states:walk.states,sampled:walk.sampled,edges:states-1,resultCalls,nextCalls,elapsedMs:Math.round(performance.now()-t)};
}

const report={};
for (const task of ['clear','covered','thin-stage-edge']) report[task]=await trial(task);
report.cost=[];
for (const n of [32,64,128,256]) report.cost.push({plain: await cost(n,false),responses: await cost(n,true)});
await writeFile(sceneRoot,JSON.stringify(report,null,2)+'\n');
for (const task of ['clear','covered','thin-stage-edge']) console.log(task,JSON.stringify({
  findings:report[task].findings, movementFrames:report[task].frames.length,
  realRedRange:[Math.min(...report[task].frames.map(p=>p.visible.reds)),Math.max(...report[task].frames.map(p=>p.visible.reds))],
  actualCentroids:new Set(report[task].frames.map(p=>p.visible.y).filter(x=>x!==null)).size,
  culledRedRange:[Math.min(...report[task].frames.map(p=>p.culled.reds)),Math.max(...report[task].frames.map(p=>p.culled.reds))],
  grayPixels:report[task].frames[0]?.visible.gray,
}));
console.log('cost',JSON.stringify(report.cost));
assert.deepEqual(report.clear.findings,[]);
assert.deepEqual(report.covered.findings,[]);
assert.ok(report.covered.frames.length>10);
assert.ok(report.covered.frames.every(p=>p.visible.reds===0 && p.culled.reds>=100));
assert.ok(report['thin-stage-edge'].findings.some(f=>f.includes('did not paint at two distinct screen positions')));
assert.ok(report['thin-stage-edge'].frames.every(f=>f.visible.reds>0 && f.culled.reds===0));
for (const {plain,responses} of report.cost) {
  assert.equal(responses.states,plain.states);
  assert.equal(responses.sampled,false);
  assert.equal(responses.resultCalls,5*responses.states*(responses.states-1)/2);
}
