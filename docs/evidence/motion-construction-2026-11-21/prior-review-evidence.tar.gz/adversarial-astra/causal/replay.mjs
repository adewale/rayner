import assert from 'node:assert/strict';
import { renderAsync } from '@resvg/resvg-js';
import { writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

const workspace = process.cwd();
const revisions = process.argv[2];
const outputs = new URL('./replay.json', import.meta.url);
const load = (root, file) => import(pathToFileURL(root + '/' + file));
const raster = svg => renderAsync(svg, {font: {loadSystemFonts: false}});
const center = (img, dx = 0) => {
  const i = 4 * ((img.height >> 1) * img.width + (img.width >> 1) + dx);
  return [...img.pixels.subarray(i, i + 3)];
};

async function runRevision(root, label) {
  const { Scene, Group, Succession, Rectangle, toSvgString, keyed, linear } = await load(root, 'src/index.ts');
  const { view } = await load(root, 'explain/view.ts');
  const { Machine } = await load(root, 'explain/machine.ts');

  const box = (key, size, color, x = 0) => keyed(new Rectangle({
    width: size, height: size, stroke: 'none', fill: color,
  }).moveTo([x, 0]), key);
  const frames = [];
  class Fade extends Scene {
    state = { flipped: false };
    async construct() {
      const picture = view(this, ({flipped}) => new Group(
        box('same-key', 0.8, flipped ? '#0000ff' : '#ff0000', flipped ? 2 : -2)),
        {place: false});
      this.add(picture);
      await this.wait(0.1);
      this.state.flipped = true;
      await this.play(picture.sync({how: 'fade', runTime: 1, rateFunc: linear}));
    }
  }
  const fade = new Fade({async frame(s) {
    if (![3, 4, 11, 18, 26, 33].includes(s.frameCount)) return;
    const img = await raster(toSvgString(s, {width: 800}));
    frames.push({frame: s.frameCount, left: center(img, -100), middle: center(img), right: center(img, 100)});
  }});
  await fade.run();

  const stages = [];
  let receipt;
  class NestedLayers extends Scene {
    state = {added: false};
    async construct() {
      const picture = view(this, ({added}) => new Group(new Group(
        box('base', 1.5, '#ff0000'), ...(added ? [box('ink', 0.8, '#0000ff')] : []),
        box('reference', 0.4, '#00ff00', 2))),
        {place: false});
      this.add(picture);
      this.addJson(() => ({picture: {entries: [{what: this.state.added ? 'Blue mark on a red field.' : 'Red field.'}]}}));
      const machine = new Machine(this, {
        start: this.state, events: ['add'], views: [picture], runTime: 1,
        next: st => st.added ? undefined : {added: true},
        transition: {add: t => {
          const ch = t.choreograph(picture);
          return new Succession([ch.enter('ink', {}, {runTime: 0.4}), ch.rest({runTime: 0.4})]);
        }},
      });
      await this.step('add');
      await this.wait(0.1);
      await this.play(machine.send('add'));
      await this.wait(0.1);
    }
  }
  const nested = new NestedLayers({async frame(s) {
    if (![3, 6, 12, 17, 21, 30, 32, 33, 34, 35, 36].includes(s.frameCount)) return;
    const img = await raster(toSvgString(s, {width: 800}));
    stages.push({frame: s.frameCount, center: center(img)});
  }});
  await nested.run();
  if (label === 'head') {
    const { exploreMachines } = await load(root, 'tools/lib/explain-check.ts');
    [receipt] = await exploreMachines(nested, NestedLayers);
  }
  return {fade: frames, nested: stages, ...(receipt && {explorer: receipt})};
}

const report = {};
for (const [label, root] of [['base', revisions + '/base'], ['main', revisions + '/main'], ['head',workspace]]) {
  report[label] = await runRevision(root,label);
}
await writeFile(outputs, JSON.stringify(report, null, 2) + '\n');
for (const [label, data] of Object.entries(report)) {
  console.log(label, JSON.stringify(data));
}
for (const label of ['base', 'head']) {
  const mid = report[label].fade.find(s => s.frame === 18);
  assert.deepEqual(mid.left, [255, 0, 0]);
  assert.deepEqual(mid.right, [0, 0, 255]);
}
for (const label of ['base', 'main']) assert.deepEqual(report[label].nested.find(s => s.frame === 30).center,[0, 0, 255]);
assert.deepEqual(report.head.nested.find(s => s.frame === 30).center,[255, 0, 0]);
assert.deepEqual(report.head.nested.at(-1).center,[0, 0, 255]);
assert.deepEqual(report.head.explorer.problems, []);
assert.deepEqual(report.head.explorer.motion, []);
