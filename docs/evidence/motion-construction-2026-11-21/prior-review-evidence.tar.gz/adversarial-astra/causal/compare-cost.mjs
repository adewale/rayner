import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const revisions = process.argv[2], n=256, rows=[];
for(const [label,root] of [['base',revisions+'/base'],['main',revisions+'/main'],['head',process.cwd()]]) {
  const load=file=>import(pathToFileURL(root+'/'+file));
  const {Scene}=await load('src/index.ts'), {Machine}=await load('explain/machine.ts');
  const {exploreMachines}=await load('tools/lib/explain-check.ts');
  let resultCalls=0, nextCalls=0;
  class Chain extends Scene{
    state={n:-1};
    async construct(){
      const machine=new Machine(this,{
        start:{n:0},events:['step'],views:[],runTime:.05,limit:n,
        next:st=>{nextCalls++;return st.n+1<n?{n:st.n+1}:undefined;},
        result:({after})=>{resultCalls++;return {number:after.n};}
      });
      await this.step('offer');
      await this.play(machine.send('step'));
    }
  }
  const source=await new Chain({async frame(){}}).run();
  resultCalls=0;nextCalls=0;
  const [walk]=await exploreMachines(source,Chain,new Map(),{events:[]});
  rows.push({label,states:walk.states,resultCalls,nextCalls});
}
console.log(rows);
await writeFile(new URL('./compare-cost.json',import.meta.url),JSON.stringify(rows,null,2)+'\n');
assert.ok(rows.every(r=>r.states===256));
assert.equal(rows[0].resultCalls,256*255/2+1);
assert.equal(rows[1].resultCalls,0);
assert.equal(rows[2].resultCalls,5*256*255/2+1);
