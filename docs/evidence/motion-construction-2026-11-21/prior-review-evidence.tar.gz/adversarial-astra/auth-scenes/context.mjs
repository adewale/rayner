import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {Resvg} from '@resvg/resvg-js';
const root=resolve(process.argv[2]??'.'), revision=process.argv[3]??'head', out=import.meta.dirname;
const {toSvgString,Text}=await import(resolve(root,'src/index.ts'));
const {loadFonts}=await import(resolve(root,'src/fonts.ts'));
const {withIntent}=await import(resolve(root,'explain/intent.ts'));
const {withSettings}=await import(resolve(root,'explain/settings.ts'));
const {LiveSink,liveSteps,runLive}=await import(resolve(root,'explain/live.ts'));
const dir=resolve(root,'scenes/explainers/poppy-sign-in');
const Raw=(await import(resolve(dir,'scene.ts'))).default;
await loadFonts();
function without(parts,fn){const family=[...new Set(parts.flatMap(p=>p.family()))],op=family.map(p=>p.style.opacity);try{family.forEach(p=>p.setStyle({opacity:0},false));return fn()}finally{family.forEach((p,i)=>p.setStyle({opacity:op[i]},false));}}
const delta=(a,b,i)=>Math.max(...[0,1,2].map(n=>Math.abs(a[i+n]-b[i+n])));
const r=[];
for(const [flow,log,moving] of [
 ['direct',['ask','approve-read','trick'],'trick:flight'],
 ['device',['ask','approve-read','collect','ask','approve-read','thief'],'thief:flight'],
 ['device',['ask'],'card:flight']]){
 const Bound=withSettings(withIntent(Raw,readFileSync(resolve(dir,'script.md'),'utf8')),{flow});
 const host=await new Bound(new LiveSink()).run(),place=liveSteps(host).get('sign-out');
 const rows=[],item={revision,flow,log,rows};let zeroSaved=false;
 await runLive(Bound,'sign-out',place,log,{from:'start',animate:{async frame(s){
 const all=s.familyMembers(),parts=(k)=>all.filter(p=>p.key===k);
 const attr=parts('page:password'), mover=parts(moving)[0],frame=rows.length;
 const paint=()=>new Resvg(toSvgString(s,{width:358}),{font:{loadSystemFonts:false}}).render();
 if(moving==='card:flight'){
 if(!mover&&frame===0){rows.push({});return;}
 const card=mover??parts('card')[0]; if(!card)return;
 const words=card.family().filter(p=>p instanceof Text).map(p=>p.text);
 const allWords=all.filter(p=>p instanceof Text).map(p=>p.text);
 if(!item.card){item.card=words;item.stageWords=allWords;}
 item.finalCard=words;item.finalStageWords=allWords;
 writeFileSync(resolve(out,`${revision}-device-code-card-358.png`),paint().asPng());
 return;
 }
 const a=paint(),b=without(attr,paint), aa=a.pixels,bb=b.pixels;
 let dotInk=0;
 for(let i=0;i<aa.length;i+=4)if(Math.abs(aa[i]-bb[i])>16||Math.abs(aa[i+1]-bb[i+1])>16||Math.abs(aa[i+2]-bb[i+2])>16)dotInk++;
 const pos=mover?.center();
 rows.push({frame,ink:dotInk,traveller:pos??null,approved:s.state.sign?.approved,hasField:!!parts('page:field').length});
 if(frame===0||(!dotInk&&mover&&frame>=18&&!zeroSaved)){
  writeFileSync(resolve(out,`${revision}-${flow}-${moving.split(':')[0]}-${frame===0?'before':'during'}-358.png`),a.asPng());
  if(frame)zeroSaved=true;
 }
 }}});
 if(moving!=='card:flight'){
 assert.ok(rows[0].ink>20&&rows.at(-1).ink>20);
 const empty=rows.filter(x=>x.traveller&&x.ink===0);
 assert.ok(new Set(empty.map(x=>x.traveller.join(','))).size>2);
 item.summary={before:rows[0].ink,after:rows.at(-1).ink,zeroWhileTravellerAppears:[empty[0].frame,empty.at(-1).frame,empty.length],distinct:new Set(empty.map(x=>x.traveller.join(','))).size};
 }else{assert.ok(item.finalCard.includes('WDJB-MJHT'));assert.ok(!item.finalStageWords.some(t=>t.includes('example.com')));}
 r.push(item);
 console.log(flow,moving,item.summary??item.finalStageWords);
}
writeFileSync(resolve(out,`${revision}-context.json`),JSON.stringify(r,null,2));
