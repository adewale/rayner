import {resolve} from 'node:path';
import {writeFileSync} from 'node:fs';
import {loadFonts, withIntent, withSettings} from '../../../explain/testing.ts';
import {readFileSync} from 'node:fs';
import {Text, VMobject, toSvgString} from '../../../src/index.ts';
import {LiveSink,liveSteps,runLive} from '../../../explain/internal.ts';
import {Resvg} from '@resvg/resvg-js';
const [name, setting, mode='geometry', selected, history]=process.argv.slice(2);
const dir=resolve('scenes/explainers',name);
const index={poppy:'approve','poppy-browser':'signin','poppy-sessions':'company','poppy-sign-in':'flow'}[name];
const Raw=(await import(resolve(dir,'scene.ts'))).default;
const Bound=withSettings(withIntent(Raw,readFileSync(resolve(dir,'script.md'),'utf8')),{[index]:setting});
await loadFonts();
const extra=new Set(['request','code','poll','poll:back','carried','carried:half','read','forged','document']);
const isMover=k=>!!k&&(k.endsWith(':flight')||k.endsWith(':return')||extra.has(k));
const out=resolve('out/adversarial-astra/auth-scenes');
const width=800;
const alphas=(p)=>{ let n=1;for(let q=p;q;q=q.parent)n*=q.style.opacity;return n;};
const order=(m)=>m instanceof VMobject&&m.hasPoints()&&alphas(m)>0.08&&((m.style.stroke!=='none'&&m.style.strokeOpacity>0)||(m.style.fill!=='none'&&m.style.fillOpacity>0));
const visible=p=>p.family().some(order);
const owner=p=>{for(let q=p;q;q=q.parent)if(q.key)return q.key;return 'unknown';};
const ancestor=(p,maybe)=>{for(let q=p;q;q=q.parent)if(q===maybe)return true;return false;};
function without(parts,cb){
 const flat=[...new Set(parts.flatMap(p=>p.family()))],op=flat.map(p=>p.style.opacity);
 try{flat.forEach(p=>p.setStyle({opacity:0},false));return cb()}
 finally{flat.forEach((p,i)=>p.setStyle({opacity:op[i]},false));}
}
const raster=scene=>new Resvg(toSvgString(scene,{width}),{font:{loadSystemFonts:false}}).render().pixels;
const delta=(a,b,i)=>Math.max(Math.abs(a[i]-b[i]),Math.abs(a[i+1]-b[i+1]),Math.abs(a[i+2]-b[i+2]));
const intersection=(a,b)=>a&&b?Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]))*Math.max(0,Math.min(a[3],b[3])-Math.max(a[1],b[1])):0;
const records=new Map();
const sink={async frame(scene){const members=scene.familyMembers(), path=scene.currentStep?.path, mls=members.filter(m=>isMover(m.key)&&visible(m)), words=members.filter(m=>m instanceof Text&&visible(m));
 const event=scene.state.last?.kind??scene.state.last?.event??scene.state.last?.tamper;
 for(const mover of mls){
 const mbox=mover.box(); if(!mbox)continue;
 const adj=words.filter(p=>!ancestor(p,mover)&&intersection(mbox,p.box())>0);
 const maxkey = k=> k;
 let actual,undr;
 for(const word of adj){
 const key=[path,event,mover.key,owner(word),word.text].join('|');
 if(selected&&!new RegExp(selected).test(key))continue;
 const overlap=intersection(mbox,word.box());const old=records.get(key)??{key,frames:0,overlap:0,hidden:0};
 old.frames++;if(overlap>old.overlap){old.overlap=overlap;old.overlapFrame=scene.frameCount;old.box=mbox;old.word=word.box();}
 if(mode==='native'){
 actual??=raster(scene);undr??=without([mover],()=>raster(scene));
 const minus=without([word],()=>raster(scene)),bare=without([mover,word],()=>raster(scene));
 let lost=0,openInk=0,masked=0,colour=0;
 for(let i=0;i<actual.length;i+=4){
 const open=delta(undr,bare,i);
 if(open<=16)continue;
 openInk++;
 const now=delta(actual,minus,i);
 if(now<open*0.15)lost++;
 if(now<open*0.6)masked++;
 if(Math.abs(now-open)>16)colour++;
 }
 if(lost>0){old.lostFrames=(old.lostFrames??0)+1;old.firstLost??=scene.frameCount;old.lastLost=scene.frameCount;}
 if(lost>old.hidden){old.hidden=lost;old.hiddenFrame=scene.frameCount;old.open=openInk;old.tint=masked;old.colour=colour;old.centre=mover.center();old.lossW=word.box();old.time=scene.time;}
 }
 records.set(key,old);
 }
 }
}};
if(history){const host=await new Bound(new LiveSink()).run();const [step,place]=[...liveSteps(host)].at(-1);await runLive(Bound,step,place,history.split(','),{from:'start',animate:sink});}
else await new Bound(sink).run();
const rows=[...records.values()].sort((a,b)=>mode==='native'?b.hidden-a.hidden:b.overlap-a.overlap);
writeFileSync(resolve(out,[name,setting,mode,history??'story',selected?.replace(/[^a-z0-9]/gi,'').slice(0,80)??'all'].join('-')+'.json'),JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.filter(r=>mode!=='native'||r.hidden>0).slice(0,30).map(r=>[r.key,r.frames,Math.round(r.overlap*100)/100,r.hidden,r.open,r.hiddenFrame])))
