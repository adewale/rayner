import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {Resvg} from '@resvg/resvg-js';
const root=resolve(process.argv[2]??'.'), revision=process.argv[3]??'head';
const out=resolve(import.meta.dirname), {toSvgString,Text}=await import(resolve(root,'src/index.ts'));
const {loadFonts}=await import(resolve(root,'src/fonts.ts'));
const {renderElements}=await import(resolve(root,'src/svg.ts')), {mobjectId}=await import(resolve(root,'src/mobject.ts'));
const {withIntent}=await import(resolve(root,'explain/intent.ts'));
const {withSettings}=await import(resolve(root,'explain/settings.ts'));
const {LiveSink,liveSteps,runLive}=await import(resolve(root,'explain/live.ts'));
await loadFonts();
const cases=[
 {id:'browser-read',name:'poppy-browser',settings:{signin:'signed-in'},log:['load','authorize'],step:'phish',mover:'read'},
 {id:'direct-key',name:'poppy-sign-in',settings:{flow:'direct'},log:['ask','approve-read','collect'],step:'sign-out',mover:'agent:key:flight'},
 {id:'device-key',name:'poppy-sign-in',settings:{flow:'device'},log:['ask','approve-read','collect'],step:'sign-out',mover:'agent:key:flight'},
];
function without(parts,fn){const family=[...new Set(parts.flatMap(p=>p.family()))],op=family.map(p=>p.style.opacity);try{family.forEach(p=>p.setStyle({opacity:0},false));return fn()}finally{family.forEach((p,i)=>p.setStyle({opacity:op[i]},false));}}
const delta=(a,b,i)=>Math.max(Math.abs(a[i]-b[i]),Math.abs(a[i+1]-b[i+1]),Math.abs(a[i+2]-b[i+2]));
const boxTouch=(a,b)=>a[0]<b[2]&&b[0]<a[2]&&a[1]<b[3]&&b[1]<a[3];
for(const c of cases){
 const dir=resolve(root,'scenes/explainers',c.name), Raw=(await import(resolve(dir,'scene.ts'))).default;
 const Bound=withSettings(withIntent(Raw,readFileSync(resolve(dir,'script.md'),'utf8')),c.settings);
 const host=await new Bound(new LiveSink()).run(), place=liveSteps(host).get(c.step);
 const data={revision,example:c.id,readerSettings:c.settings,eventLog:c.log,step:c.step,measurements:{}};
 let origin;
 await runLive(Bound,c.step,place,c.log,{from:'start',animate:{async frame(scene){
 origin??=scene.time;
 const members=scene.familyMembers(), words=members.filter(p=>p instanceof Text&&p.key==='agent:name');
 const m=members.find(p=>p.key===c.mover);
 if(!m||words.length!==1||!boxTouch(m.box(),words[0].box())) return;
 const y=m.center()[1],nearest=Math.abs(y-1.12);
 if(!data.paintOrder||nearest<data.paintOrder.distance){
 const ordered=renderElements(scene,{width:800}),indices=p=>{const ids=new Set(p.family().map(mobjectId));return ordered.flatMap((n,i)=>ids.has(n.id)?[i]:[]);};
 data.paintOrder={distance:nearest,y,rel:Math.round((scene.time-origin)*30),mover:indices(m),label:indices(words[0])};
 }
 for(const width of [800,358]){
 const item=data.measurements[width]??={loss:[],observations:[],worst:{hidden:-1}};
 const paint=()=>new Resvg(toSvgString(scene,{width}),{font:{loadSystemFonts:false}}).render();
 const draws=[paint(),without([m],paint),without(words,paint),without([m,...words],paint)];
 const [actual,withoutMover,withoutWord,bare]=draws.map(d=>d.pixels);
 let hidden=0,open=0;
 for(let i=0;i<actual.length;i+=4){const full=delta(withoutMover,bare,i);if(full<=16)continue;open++;if(delta(actual,withoutWord,i)<.15*full)hidden++;}
 const rel=Math.round((scene.time-origin)*30);
 item.observations.push([rel,hidden,open]);if(hidden)item.loss.push([rel,hidden]);
 if(hidden>item.worst.hidden){item.worst={relFrame:rel,hidden,exposed:open,screenWidth:width,sceneFrame:scene.frameCount,box:words[0].box(),moverBox:m.box()};
 for(const [i,label] of ['actual','without-mover','without-label','without-both'].entries())writeFileSync(resolve(out,[revision,c.id,width,label].join('-')+'.png'),draws[i].asPng());}
 }
 }}});
 for(const item of Object.values(data.measurements))assert.ok(item.worst.hidden>=0);
 writeFileSync(resolve(out,[revision,c.id,'reader'].join('-')+'.json'),JSON.stringify(data,null,2));
 console.log(c.id,data.measurements);
}
