import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {Resvg} from '@resvg/resvg-js';
const root=resolve(process.argv[2]??'.'),rev=process.argv[3]??'head',out=import.meta.dirname;
const {loadFonts}=await import(resolve(root,'src/fonts.ts'));
const {toSvgString}=await import(resolve(root,'src/index.ts'));
const {withIntent}=await import(resolve(root,'explain/intent.ts'));
const {withSettings}=await import(resolve(root,'explain/settings.ts'));
const dir=resolve(root,'scenes/explainers/poppy-browser'),Raw=(await import(resolve(dir,'scene.ts'))).default;
const Bound=withSettings(withIntent(Raw,readFileSync(resolve(dir,'script.md'),'utf8')),{signin:'signed-in'});
await loadFonts();
const r={rev,before:0,after:0,rows:[]};let moved=false,saved=false;
await new Bound({async frame(s){
 if(s.currentStep?.path!=='fetch')return;
 const members=s.familyMembers(),m=members.find(p=>p.key==='ticket:flight'),label=members.find(p=>p.key==='rack:none');
 if(!m&&((r.before>300&&!moved)||(r.after>300&&moved)))return;
 const draw=()=>new Resvg(toSvgString(s,{width:358}),{font:{loadSystemFonts:false}}).render();
 const actual=draw(),a=actual.pixels,part=label?.family()??[],alpha=part.map(p=>p.style.opacity);let b;
 try{part.forEach(p=>p.setStyle({opacity:0},false));b=draw().pixels;}finally{part.forEach((p,i)=>p.setStyle({opacity:alpha[i]},false));}
 let ink=0;for(let i=0;i<a.length;i+=4)if(Math.abs(a[i]-b[i])>16||Math.abs(a[i+1]-b[i+1])>16||Math.abs(a[i+2]-b[i+2])>16)ink++;
 if(m){moved=true;r.rows.push({frame:s.frameCount,ink,at:m.center()});if(!saved&&r.rows.length>12){saved=true;writeFileSync(resolve(out,rev+'-browser-empty-fetch-358.png'),actual.asPng());}}
 else if(moved)r.after=Math.max(ink,r.after);else r.before=Math.max(ink,r.before);
 }}).run();
console.log(rev,r.before,r.after,r.rows.length,Math.min(...r.rows.map(x=>x.ink)),Math.max(...r.rows.map(x=>x.ink)));
writeFileSync(resolve(out,rev+'-browser-empty-fetch.json'),JSON.stringify(r,null,2));
