import {loadFonts,loadProject} from '../../../explain/testing.ts';
import {liveSteps,LiveSink,runLive} from '../../../explain/internal.ts';
import {Text,VMobject} from '../../../src/index.ts';
import {resolve} from 'node:path';
import {writeFile} from 'node:fs/promises';
const subjects={refusals:['pace',[['mcp','answer','expire','answer'],['mcp','answer','read-only','answer'],['mcp','answer','old-copy','answer'],['mcp','answer','mcp'],['mcp','answer','end','answer']]],coverage:['skill',[['close account','gift card','read tasks'],['gift card','close account','read tasks'],['read tasks','gift card','close account'],['read tasks','use skill'],['close account','read tasks','use skill'],['gift card','read tasks','report'],['gift card','read tasks','report','close account'],['gift card','read tasks','report','use skill','use alternative']]],conversations:['close',[['you'],['ask','person','direct','joins'],['ask','read','direct','you','read'],['ask','read','invite','direct','read'],['ask','read','invite','direct','joins'],['ask','read','invite','ask'],['ask','read','person','joins','read'],['you','you','read'],['ask','read','direct','you','read','close']]],discovery:['one-company',[]]};
await loadFonts();
const chapter=process.argv[2], opts=process.argv.slice(3), [step,logs]=subjects[chapter];
const{default:Source}=await import(`../../../scenes/explainers/poppy-${chapter}/scene.ts`);
const dir=resolve(`scenes/explainers/poppy-${chapter}`),project=await loadProject(Source,dir);
const [scenario]=project.scenarios;
const visible=m=>m.family().some(m=>m instanceof VMobject&&m.hasPoints()&&m.style.opacity*Math.max(m.style.fillOpacity,m.style.strokeOpacity)>.06);
const moverRe=/(:flight$|^list$|^report:(sent|reply)$|^skill:read$|^probe:(api|web|chat)$|^sheet:token$|^document$|^delegation$|^fresh-seal$)/;
const area=(a,b)=>Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]))*Math.max(0,Math.min(a[3],b[3])-Math.max(a[1],b[1]));
const totals=[];
function observe(label){const pairs=new Map();let t0;return {get:()=>({label,pairs:[...pairs.values()].sort((a,b)=>b.fraction-a.fraction)}),async frame(s){const f=s.familyMembers();t0??=s.time;const mvs=f.filter(m=>m.key&&moverRe.test(m.key)&&visible(m));if(!mvs.length)return;const words=f.filter(m=>m instanceof Text&&visible(m));const marks=f.filter(m=>m.key&&/^(agent:station|.*:mark|agent:seal|agent:(mcp-)?key|shop:door)$/.test(m.key)&&visible(m));for(const mover of mvs){const family=new Set(mover.family()),a=mover.box();for(const other of [...words,...marks]){if(family.has(other)||other.family().includes(mover))continue;const b=other.box();if(!a||!b)continue;const overlap=area(a,b)/Math.max(1e-8,area(b,b));if(overlap<.005)continue;let par=other,rootkey='';while(par){if(par.key){rootkey=par.key;break}par=par.parent;}
const key=`${s.currentStep?.path}/${mover.key}/${rootkey}/${other.text??''}`;const row=pairs.get(key)??{step:s.currentStep?.path,mover:mover.key,victim:rootkey,words:other.text,count:0,fraction:0};row.count++;if(overlap>row.fraction){row.fraction=+overlap.toFixed(4);row.at=+(s.time-t0).toFixed(4);row.frame=s.frameCount;row.moverAt=mover.center();row.victimAt=other.center();row.state=s.stateJson();}pairs.set(key,row);}}}};}
const o=observe('story');await new scenario.Scene(o).run();totals.push(o.get());const base=await new scenario.Scene(new LiveSink()).run(),place=liveSteps(base).get(step);if(!place)throw new Error(`no live place ${step}`);
for(const log of logs){let o=observe(log.join(' > '));try{await runLive(scenario.Scene,step,place,log,{from:'start',animate:o});totals.push(o.get());}catch(e){totals.push({label:log.join(' > '),error:e.message});}}
await writeFile(`out/adversarial-astra/other-scenes/${chapter}-geometry.json`,JSON.stringify(totals,null,2)); console.log(chapter,totals.map(o=>[o.label,o.error||o.pairs.length]));
