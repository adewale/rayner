import {loadFonts,loadProject} from '../../../explain/testing.ts';
import {renderAsync} from '@resvg/resvg-js';
import {toSvgString} from '../../../src/index.ts';
import Discovery from '../../../scenes/explainers/poppy-discovery/scene.ts';
await loadFonts(); const [scenario]=(await loadProject(Discovery,'scenes/explainers/poppy-discovery')).scenarios;
let checked=0,nonzero=0,min=Infinity,max=-Infinity;
await new scenario.Scene({async frame(s){if(s.currentStep?.path!=='copy')return;const m=s.find('sheet:token');if(!m)return;min=Math.min(min,m.center()[0]);max=Math.max(max,m.center()[0]);const full=toSvgString(s,{width:800});const all=m.family(),o=all.map(p=>p.style.opacity);all.forEach(p=>p.setStyle({opacity:0},false));let bare;try{bare=toSvgString(s,{width:800});}finally{all.forEach((p,i)=>p.setStyle({opacity:o[i]},false));}const [a,b]=await Promise.all([full,bare].map(svg=>renderAsync(svg,{font:{loadSystemFonts:false}})));checked++;if(!a.pixels.equals(b.pixels))nonzero++;}}).run();console.log(JSON.stringify({checked,nonzero,min,max}));
