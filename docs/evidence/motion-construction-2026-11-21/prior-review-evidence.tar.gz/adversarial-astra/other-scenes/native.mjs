import {loadFonts,loadProject} from '../../../explain/testing.ts';
import {liveSteps,LiveSink,runLive,liveBase} from '../../../explain/internal.ts';
import {Text,VMobject,toSvgString} from '../../../src/index.ts';
import {renderAsync} from '@resvg/resvg-js';
import {resolve} from 'node:path';
import {writeFile} from 'node:fs/promises';
const chapter=process.argv[2], printDir='out/adversarial-astra/other-scenes';
const groups={coverage:{'report:reply':['desk:seen','desk:why','feedback:name'],'report:sent':['lane:chat:name'],'strip:aside:1:flight':['strip:aside:2']},refusals:{document:['lane:api:name','agent:name','agent:mcp-key:name']},discovery:{'sheet:token':['url:path']},conversations:{'specialist:mark:flight':['direct:agent:mark','written:role:label']}};
const byChapter={refusals:['pace',['old-copy','answer']],coverage:['skill',['close account']],discovery:['one-company',null],conversations:['close',null]};
const [step,log]=byChapter[chapter];const wanted=groups[chapter];const options={font:{loadSystemFonts:false}}, width=800;
await loadFonts();const{default:Source}=await import(`../../../scenes/explainers/poppy-${chapter}/scene.ts`);
const project=await loadProject(Source,resolve(`scenes/explainers/poppy-${chapter}`));
const boxOverlap=(a,b)=>a&&b&&Math.min(a[2],b[2])>Math.max(a[0],b[0])-.075&&Math.min(a[3],b[3])>Math.max(a[1],b[1])-.075;
const rgbaDiff=(a,b,i)=>Math.max(Math.abs(a[i]-b[i]),Math.abs(a[i+1]-b[i+1]),Math.abs(a[i+2]-b[i+2]));
function without(parts,cb){const family=[...new Set(parts.flatMap(x=>x.family()))];const alpha=family.map(m=>m.style.opacity);try{family.forEach(m=>m.setStyle({opacity:0},false));return cb();}finally{family.forEach((m,i)=>m.setStyle({opacity:alpha[i]},false));}}
const exists=m=>m.family().some(p=>p instanceof VMobject&&p.hasPoints()&&p.style.opacity*Math.max(p.style.fillOpacity,p.style.strokeOpacity)>.025);
const all=[];let recent=null;
for(const scenario of project.scenarios){const host=await new scenario.Scene(new LiveSink()).run(), place=liveSteps(host).get(step), base=(await liveBase(scenario.Scene,step,place)).base;
const labels={settings:scenario.values,base:base.from,hasEventsAt:[...liveSteps(host).keys()],baseState:base.state,events:place.machine.spec.events.map(e=>[e,'next' in place.machine.outcome(base.state,e)])};
for(const kind of ['story',...(log?['reader']:[])]){let first,frame=0;const rows=new Map();const callback={async frame(s){first??=s.time;frame++;const family=s.familyMembers();for(const [mkey,keys] of Object.entries(wanted)){const movers=family.filter(m=>m.key===mkey&&exists(m));for(const m of movers)for(const k of keys){const targets=family.filter(v=>v.key===k&&exists(v)).flatMap(v=>chapter==='coverage'&&k==='strip:aside:2'?v.family().filter(x=>x instanceof Text):[v]);for(const v of targets){const key=`${s.currentStep?.path}/${mkey}/${k}/${v.text??''}`;const rec=rows.get(key)??{key,coexisting:0,broad:0,damaged:0,maxLost:0};rows.set(key,rec);rec.coexisting++;if(!boxOverlap(m.box(),v.box()))continue;rec.broad++;
const snap=()=>toSvgString(s,{width});const svgs=[snap(),without([v],snap),without([m],snap),without([m,v],snap)];const pics=await Promise.all(svgs.map(x=>renderAsync(x,options)));const[a,b,c,d]=pics.map(im=>im.pixels);let lost=0,exposed=0,mask=0,remaining=0;for(let i=0;i<a.length;i+=4){const open=rgbaDiff(c,d,i);if(rgbaDiff(a,c,i)>16)mask++;if(open<=16)continue;exposed++;const actual=rgbaDiff(a,b,i);if(actual<=.15*open)lost++;if(actual>16)remaining++;}
if(lost){rec.damaged++;rec.first??=+(s.time-first).toFixed(3);rec.last=+(s.time-first).toFixed(3);}if(lost>rec.maxLost){Object.assign(rec,{maxLost:lost,exposed,mask,remaining,time:+(s.time-first).toFixed(3),frame,where:m.center(),victim:v.center()});const file=`${chapter}-${Object.values(scenario.values).join('-')||'std'}-${kind}-${s.currentStep?.path}-${mkey}-${k}`.replaceAll(':','_');await writeFile(`${printDir}/${file}.png`,pics[0].asPng());await writeFile(`${printDir}/${file}-no-mover.png`,pics[2].asPng());}}}}}};
try{if(kind==='story')await new scenario.Scene(callback).run();else await runLive(scenario.Scene,step,place,log,{from:base.from,animate:callback});all.push({kind,log:kind==='reader'?log:undefined,labels,rows:[...rows.values()]});}catch(e){all.push({kind,labels,error:e.message});}
await writeFile(`${printDir}/${chapter}-native.json`,JSON.stringify(all,null,2));console.log(chapter,kind,labels.base,labels.settings,[...rows.values()].filter(r=>r.maxLost).map(r=>[r.key,r.maxLost,r.damaged]));}}
