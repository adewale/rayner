import {loadFonts,loadProject} from '../../../explain/testing.ts';
import {liveSteps,LiveSink,liveBase,runLive} from '../../../explain/internal.ts';
import {acceptedLog} from '../../../app/embed-live.ts';
import {toSvgString} from '../../../src/index.ts';
import {renderAsync} from '@resvg/resvg-js';
import {resolve} from 'node:path';
import {writeFile} from 'node:fs/promises';
await loadFonts();
const log=['push','push','push','push','pop','pop','push','pop','pop','pop'];
const dir='out/adversarial-astra/other-scenes', rows=[];
for(const id of ['ring-buffer','poppy-coverage','poppy-conversations']){
const {default:Source}=await import(`../../../scenes/explainers/${id}/scene.ts`);
const project=await loadProject(Source,resolve(`scenes/explainers/${id}`));
for(const scenario of project.scenarios){
 const host=await new scenario.Scene(new LiveSink()).run(),places=liveSteps(host),step=({'ring-buffer':'implementation-result','poppy-coverage':'skill','poppy-conversations':'close'})[id];
 const place=places.get(step),{machine,base}=await liveBase(scenario.Scene,step,place);
 const show=(s)=>({head:s.head,tail:s.tail,next:s.next,length:s.length,data:s.data,returned:s.returned,tray:s.tray});
 const row={id,scenario:scenario.values,step,from:base.from,offers:[...places.keys()]};
 if(id==='ring-buffer'){
 const {kept,stopped}=acceptedLog(machine,base.state,log),count=scenario.values.operations==='wrap'?3:5;
 const actualLog=Array(count).fill('pop');const valid=acceptedLog(machine,base.state,actualLog);
 row.start=show(base.state);row.claimedLog={kept,stopped};row.actualLog=actualLog;
 const before=valid.states.at(-2),after=valid.states.at(-1),slot=before.head,k=after.tray.values.length-1;
 const keys=[`ring:value:${slot}`,`ring:tray:${k}:source:0:ring:value:${slot}`,`ring:tray:${k}`];
 row.keys=keys;let start;const native=[];const times=[0,.5,19/30,2.1];
 await runLive(scenario.Scene,step,place,actualLog,{from:base.from,animate:{async frame(s){start??=s.time;const t=s.time-start;if(!times.length||t+.00001<times[0])return;times.shift();const svg=()=>toSvgString(s,{width:1280});const full=await renderAsync(svg(),{font:{loadSystemFonts:false}}),rgba=full.pixels;const ink=[];for(const key of keys){const obj=s.find(key);if(!obj){ink.push(0);continue;}const all=obj.family(),alpha=all.map(m=>m.style.opacity);all.forEach(m=>m.setStyle({opacity:0},false));let missing;try{missing=(await renderAsync(svg(),{font:{loadSystemFonts:false}})).pixels;}finally{all.forEach((m,i)=>m.setStyle({opacity:alpha[i]},false));}let n=0;for(let i=0;i<rgba.length;i+=4)if(rgba[i]!==missing[i]||rgba[i+1]!==missing[i+1]||rgba[i+2]!==missing[i+2])n++;ink.push(n);}native.push({time:+t.toFixed(4),ink});}}});
 row.actualKept=valid.kept;row.returned=after.returned;row.native=native;
 }else{
 const queue=[base.state],seen=new Set([JSON.stringify(base.state)]),accepted=new Set(),paths={};
 for(let i=0;i<queue.length;i++)for(const e of machine.spec.events){const o=machine.outcome(queue[i],e);if(!('next'in o))continue;accepted.add(e);const k=JSON.stringify(o.next);if(!seen.has(k)){seen.add(k);queue.push(o.next);}}
 row.reachableStates=seen.size;row.allAccepted=[...accepted];row.neverAccepted=machine.spec.events.filter(e=>!accepted.has(e));
 }
 rows.push(row); console.log(id,scenario.values, base.from,row.claimedLog||row.neverAccepted,row.native||''); await writeFile(`${dir}/reader-roots.json`,JSON.stringify(rows,null,2));
}}
