import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {renderAsync} from '@resvg/resvg-js';
import {Scene, Group, Rectangle, Succession, keyed, toSvgString} from '../../../src/index.ts';
import {Machine,view} from '../../../explain/index.ts';
import {pass} from '../../../explain/drawing.ts';
import {MachineMotionCheck} from '../../../tools/lib/explain-motion-rules.ts';

const ink = (width,height,color) => new Rectangle({width,height,fill:color,stroke:'none'});
const rows = [];
for (const moveUnderCover of [false,true]) {
  const xs = [], images = new Set();
  let trip;
  class Example extends Scene {
    state = {sent:false};
    async construct() {
      const target = view(this, () => new Group(keyed(ink(0.5,0.5,'#ff0000').moveTo([0,2]),'caption')), {place:false});
      const hiddenBacking = ink(0.55,0.55,'#224466').moveTo([-0.35,0]);
      const driver = new Group();
      driver.addUpdater(() => {
        if (moveUnderCover && trip?.phase === 'begun') hiddenBacking.moveTo([0.175*trip.mobject.center()[0],0]);
      });
      const machine = new Machine(this,{
        views:[target],start:this.state,events:['ship'],next:()=>({sent:true}),runTime:1.4,
        motion:()=>[{view:target,during:'parcel',present:['caption']}],
        transition:{ship: t => {
          const c=t.choreograph(target), parcel=ink(9,1.3,'#224466');
          parcel.clipBox=[-1,-0.45,1,0.45];
          const beats=pass(c,'parcel',parcel,[[-2,0],[2,0]],{appear:0.1,move:0.8,leave:0.1});
          trip=beats[1]; return new Succession([...beats,c.rest({runTime:0.1})]);
        }},
      });
      this.add(hiddenBacking,target,driver);
      await this.step('shipment');
      await this.play(machine.send('ship'));
    }
  }
  const check=new MachineMotionCheck(), scene=new Example({async frame(s) {
    await check.frame(s);
    if (trip?.phase !== 'begun') return;
    const image=await renderAsync(toSvgString(s,{width:800}),{font:{loadSystemFonts:false}});
    xs.push(trip.mobject.center()[0]);
    images.add(createHash('sha256').update(image.pixels).digest('hex'));
  }});
  await check.during(scene,()=>scene.run());
  assert.ok(xs.length>15 && Math.max(...xs)-Math.min(...xs)>3);
  assert.equal(images.size,1);
  rows.push({moveUnderCover,frames:xs.length,distinctNativeRGBA:images.size,worldX:[Math.min(...xs),Math.max(...xs)],findings:check.findings});
}
console.log(JSON.stringify(rows,null,2));
