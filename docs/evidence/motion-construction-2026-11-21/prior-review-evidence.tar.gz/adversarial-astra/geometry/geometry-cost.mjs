import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const base = process.env.RAYNER_REPRO_ROOT || process.cwd();
const moduleAt = file => import(pathToFileURL(resolve(base,file)).href);
const { Scene, Circle, keyed } = await moduleAt('src/index.ts');
const { KeyedMotionSink } = await moduleAt('src/keyed-motion.ts');
const count = 120;
class Still extends Scene {
  async construct() {
    await this.step('static artwork');
    for (let i=0; i<count; i++) this.add(keyed(new Circle({radius:0.26,fill:'#4873a1',stroke:'none'})
      .moveTo([-7.25+i%15, -3.5+Math.floor(i/15)]), 'dot '+i));
    await this.wait(2);
  }
}
const sink = new KeyedMotionSink(()=>'static scene');
const initial = process.memoryUsage();
const start = performance.now();
await new Still(sink).run();
const sampled = performance.now(), retained = process.memoryUsage();
const results = sink.finish();
assert.deepEqual(results,[]);
console.log(JSON.stringify({base,shapes:count,frames:sink.frames,samplingMs:Math.round(sampled-start),
  totalMs:Math.round(performance.now()-start),rssBeforeMiB:+(initial.rss/2**20).toFixed(1),
  rssAfterSamplingMiB:+(retained.rss/2**20).toFixed(1),heapAfterSamplingMiB:+(retained.heapUsed/2**20).toFixed(1),
  maxRssMiB:+(process.resourceUsage().maxRSS/1024).toFixed(1)}));
