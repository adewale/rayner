import assert from 'node:assert/strict';
import { copyFile, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { buildInputs } from '../../../tools/lib/build-inputs.ts';
import { reviewCodeHash } from '../../../tools/lib/explain-review-plan.ts';

const repo = resolve(import.meta.dirname, '../../..');
const temp = await mkdtemp(join(tmpdir(), 'rayner-review-fingerprint-'));
try {
  const reviewPath = 'tools/lib/explain-review-plan.ts';
  const source = await readFile(join(repo, reviewPath), 'utf8');
  const list = source.match(/export async function reviewCodeHash[\s\S]*?const files = \[([\s\S]*?)\];/)[1];
  const owners = [...list.matchAll(/'(tools\/[^']+)'/g)].map(m => m[1]);
  const helpers = ['tools/lib/explain-motion-rules.ts', 'tools/lib/explain-film.ts'];
  const build = await buildInputs(repo);
  assert.equal(build.inputs.some(row => helpers.includes(row.file)), false);
  for (const path of [...owners, ...helpers]) {
    await mkdir(dirname(join(temp, path)), {recursive: true});
    await copyFile(join(repo, path), join(temp, path));
  }
  const before = await reviewCodeHash(temp, build.hash);
  const after = {};
  for (const path of helpers) {
    await writeFile(join(temp, path), 'throw new Error("fixture verifier changed");\n');
    after[path] = await reviewCodeHash(temp, build.hash);
    assert.equal(after[path], before, path);
  }
  await writeFile(join(temp, reviewPath), 'throw new Error("known verifier changed");\n');
  const control = await reviewCodeHash(temp, build.hash);
  assert.notEqual(control, before);
  const receipt = {buildInputs: build.inputs.length, helperIncludedInBuildHash: false, before, after, includedOwnerControl: control};
  await writeFile(join(import.meta.dirname, 'receipt-proof.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt));
} finally {
  await rm(temp, {recursive: true, force: true});
}
