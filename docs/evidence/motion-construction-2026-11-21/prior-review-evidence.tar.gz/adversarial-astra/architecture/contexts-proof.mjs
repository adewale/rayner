import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { liveBase, runLive } from '../../../explain/live.ts';
import { toSvgString } from '../../../src/index.ts';
import { collectProject } from '../../../tools/lib/explain-project.ts';
import { filmProject } from '../../../tools/lib/explain-film.ts';
import { liveVisits } from '../../../tools/lib/explain-live-review.ts';
import { rasterize } from '../../../tools/lib/explain-raster.ts';

const root = import.meta.dirname;
const project = await collectProject(join(root, 'contexts'), { capture: false, write: false });
const scenario = project.scenarios[0];
const place = scenario.live.get('offer');
const { machine, base } = await liveBase(scenario.Scene, 'offer', place);
const colors = { red: [204,17,0], blue: [34,68,221], green: [17,204,0] };
async function center(scene) {
  const image = await rasterize(toSvgString(scene, { width: 240 }));
  const offset = 4 * (Math.floor(image.height / 2) * image.width + Math.floor(image.width / 2));
  return Array.from(image.pixels.subarray(offset, offset + 3));
}
const sourceColors = {};
for (const sent of [[], ['mark'], ['ship']]) {
  const seen = await runLive(scenario.Scene, 'offer', place, sent, { from: base.from });
  sourceColors[JSON.stringify(sent)] = await center(seen.scene);
}
assert.deepEqual(Object.values(sourceColors), [colors.green, colors.red, colors.blue]);
const shipAfterMark = [];
await runLive(scenario.Scene, 'offer', place, ['mark', 'ship'], { from: base.from, animate: {async frame(scene) {
  shipAfterMark.push(await center(scene));
}}});
assert.deepEqual(shipAfterMark[0], colors.red);
assert.deepEqual(shipAfterMark.at(-1), colors.blue);
const film = await filmProject(project, join(root, 'contexts-film'));
const filmed = film.films.filter(f => f.event).map(f => [...f.path, f.event]);
const servedReview = liveVisits(machine, base.state);
assert.deepEqual(filmed, [['mark'], ['ship']]);
assert.deepEqual(servedReview, [['mark']]);
const receipt = { modelStates: machine.reachable(base.state).length, acceptedFirstPresses: machine.spec.events, sourceColors,
  shipAfterMark, filmed, servedReview };
await writeFile(join(root, 'contexts-proof.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt));
