import { Scene, Group, Rectangle, keyed } from 'rayner';
import { Machine, view } from 'rayner/explain';

export default class Responses extends Scene {
  static meta = { id: 'contexts' };
  state = { ready: true };
  shown: { result?: { response: string } } = {};

  async construct() {
    await this.step('offer', { caption: 'Choose a response.' });
    const picture = view(this, (_state, shown) => {
      const fill = shown.result?.response === 'mark' ? '#cc1100' : shown.result?.response === 'ship' ? '#2244dd' : '#11cc00';
      return new Group(keyed(new Rectangle({ width: 2, height: 1, fill, stroke: 'none' }), 'response'));
    }, { place: false });
    this.add(picture);
    const machine = new Machine(this, {
      start: this.state,
      views: [picture],
      events: ['mark', 'ship'] as const,
      next: state => ({ ...state }),
      result: ({ event }) => ({ response: event }),
      runTime: 0.2, transition: {ship() {throw new Error("fixture: unrenderable reader ship");}},
    });
    machine.offer();
    await this.wait(0.2);
  }
}
