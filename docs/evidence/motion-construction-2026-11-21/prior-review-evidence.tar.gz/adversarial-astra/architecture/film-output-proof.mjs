import assert from 'node:assert/strict';
import { mkdir, readFile, rm, writeFile, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { run } from '../../../tools/explain.ts';

const root = import.meta.dirname, previous = join(root, 'contexts'), damaged = join(root, 'failed-reader-film');
const output = join(root, 'film-output-during-error');
const io = () => {
  const rows = {stdout: '', stderr: ''};
  return {rows, stdout(text) { rows.stdout += text; }, stderr(text) { rows.stderr += text; }};
};
await mkdir(damaged, {recursive: true});
const source = await readFile(join(previous, 'scene.ts'), 'utf8');
await writeFile(join(damaged, 'scene.ts'), source.replace('runTime: 0.2,', 'runTime: 0.2, transition: {ship() {throw new Error("fixture: unrenderable reader ship");}},'));
const first = io(), second = io();
assert.equal(await run(['film', previous, '--out', output], first), 0, first.rows.stderr);
const before = await readFile(join(output, 'film.json'), 'utf8');
await writeFile(join(output, 'frames', 'notes.txt'), 'file owned by this isolated fixture');
const status = await run(['film', damaged, '--out', output], second);
assert.equal(status, 1);
assert.match(second.rows.stderr, /fixture: unrenderable reader ship/);
const after = await readFile(join(output, 'film.json'), 'utf8');
assert.equal(before, after);
const missing = [];
for (const seq of JSON.parse(after).films) for (const f of seq.frames)
  if (!(await stat(join(output,'frames',f.png)).catch(() => null))) missing.push(f.png);
assert.ok(missing.length);
const notes = await stat(join(output,'frames','notes.txt')).catch(() => null);
assert.equal(notes, null);
const proof = {firstOutput: first.rows.stdout.trim(), secondStatus: status, secondError: second.rows.stderr.trim(),
  previousManifestStillPresent: true, manifestFrameFilesMissing: missing, deletedUnrelatedFixtureFile: !notes};
await writeFile(join(root,'film-output-proof.json'), JSON.stringify(proof,null,2) + '\n');
console.log(JSON.stringify(proof));
