import {writeFile} from 'node:fs/promises';
import {renderAsync} from '@resvg/resvg-js';
import {Scene, Group, Rectangle, Succession, keyed, toSvgString} from '/workspace/rayner-audit/src/index.ts';
import {Machine, view} from '/workspace/rayner-audit/explain/index.ts';
import {pass} from '/workspace/rayner-audit/explain/drawing.ts';
import {MachineMotionCheck} from '/workspace/rayner-audit/tools/lib/explain-motion-rules.ts';
class Probe extends Scene<{n:number}> {
 override state={n:0};
 override async construct() {
  const picture=view(this,()=>new Group(
   keyed(new Rectangle({width:1,height:.5,fill:'#ff0000',stroke:'none'}).moveTo([0,2]),'context'),
   keyed(new Rectangle({width:1.2,height:.7,fill:'#000000',stroke:'none'}).moveTo([0,2]),'cover'),
  ),{place:false});
  const machine=new Machine(this,{start:this.state,events:['ship'],views:[picture],runTime:1,next:st=>({n:st.n+1}),
   motion:()=>[{view:picture,during:'parcel',present:['context']}],
   transition:{ship:t=>{const c=t.choreograph(picture);return new Succession([...pass(c,'parcel',new Rectangle({width:.3,height:.3,fill:'#00ff00',stroke:'none'}),[[-2,0],[2,0]],{appear:.1,move:.5,leave:.1}),c.rest({runTime:.1})]);}},
  });
  this.add(picture);await this.play(machine.send('ship'));
 }
}
const checker=new MachineMotionCheck();let snapshots:{actual:string;minus:string;exposed:string}|undefined;
const scene=new Probe({async frame(s){await checker.frame(s);if(snapshots||!s.find('parcel'))return;
 const context=s.find('context')!,cover=s.find('cover')!,actual=toSvgString(s,{width:800});
 context.setOpacity(0);const minus=toSvgString(s,{width:800});context.setOpacity(1);
 cover.setOpacity(0);const exposed=toSvgString(s,{width:800});cover.setOpacity(1);snapshots={actual,minus,exposed};
}});
await checker.during(scene,()=>scene.run());
if(!snapshots)throw new Error('probe never painted');
const render=async(svg:string)=>(await renderAsync(svg,{font:{loadSystemFonts:false}}));
const a=await render(snapshots.actual),b=await render(snapshots.minus),c=await render(snapshots.exposed);
const ap=a.pixels,bp=b.pixels,cp=c.pixels;let hidden=0,exposed=0;
for(let i=0;i<ap.length;i+=4){if([0,1,2].some(k=>ap[i+k]!==bp[i+k]))hidden++;if([0,1,2].some(k=>ap[i+k]!==cp[i+k]))exposed++;}
const result={findings:checker.findings,contextContributionPixels:hidden,exposedByRemovingCoverPixels:exposed};
await writeFile(new URL('./context-occlusion-probe.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
await writeFile(new URL('./context-occlusion-probe.png',import.meta.url),a.asPng());
console.log(JSON.stringify(result));
