import json,sys,pathlib
from PIL import Image,ImageDraw
root=pathlib.Path('/workspace/rayner-audit/out/current-audit-2026-11-22')
id=sys.argv[1]; nums=list(map(int,sys.argv[2].split(','))); crop=tuple(map(int,sys.argv[3].split(','))) if len(sys.argv)>3 else (0,0,800,450)
w,h=crop[2]-crop[0],crop[3]-crop[1]
out=Image.new('RGB',(w*2,(h+24)*len(nums)),'white'); d=ImageDraw.Draw(out); led=[]
for row,n in enumerate(nums):
 for col,side in enumerate(('baseline','variant')):
  rec=json.loads((root/id/side/'receipt.json').read_text());f=next((x for x in rec['frames'] if x['sequence']==n),None)
  if f:
   asset=root/id/side/'assets'/(f['asset']+'.png')
   if not asset.exists():asset=root/id/side/(f['asset']+'.png')
   if not asset.exists():asset=root/id/'assets'/(f['asset']+'.png')
   im=Image.open(asset).crop(crop);out.paste(im,(col*w,row*(h+24)+24));d.text((col*w+4,row*(h+24)+5),f"{side} sequence{n} native{f['frame']} ({f['frame']/30:.3f}s)",fill='black');led.append(dict(side=side,sequence=n,frame=f['frame'],absolute=f['absolute'],step=f['step'],asset=str(asset),crop=crop))
  else:d.text((col*w+4,row*(h+24)+5),f'{side} sequence{n} NO FRAME',fill='black')
p=root/'review-second-witness'/(id.replace('/','--')+'--'+sys.argv[2].replace(',','-')+'.png');out.save(p);p.with_suffix('.json').write_text(json.dumps(led,indent=2));print(p)
